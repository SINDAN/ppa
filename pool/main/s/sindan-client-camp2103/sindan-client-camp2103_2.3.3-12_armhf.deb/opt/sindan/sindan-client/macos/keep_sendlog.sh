#!/bin/sh

while true 
do
	sh ./sendlog.sh
	sleep 15
done

#!/bin/sh

while true 
do
	./sindan.sh
	sleep 15
done
